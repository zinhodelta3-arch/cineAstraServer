import { idString } from '../utils/dto.js';

export function createComboModel(database) {
    const rows = async (c, sql, params = []) => (await c.execute(sql, params))[0];
    const one = async (c, sql, params = []) => (await rows(c, sql, params))[0] ?? null;
    return {
        supervisorLocation: (id, c = database) => one(c, 'SELECT id_local FROM supervisor_locais WHERE id_supervisor = ?', [id]),
        local: (id, c = database, lock = false) => one(c, `SELECT id_local,status FROM locais WHERE id_local = ?${lock ? ' FOR UPDATE' : ''}`, [id]),
        combo: (id, c = database, lock = false) => one(c, `SELECT c.id_combo,c.id_local,c.nome,c.descricao,c.preco,c.ativo,c.data_cadastro, (SELECT im.url FROM combos_imagens im WHERE im.id_combo=c.id_combo AND im.tipo='PRINCIPAL' ORDER BY im.ordem,im.id_imagem LIMIT 1) AS imagem FROM combos c WHERE c.id_combo = ?${lock ? ' FOR UPDATE' : ''}`, [id]),
        inputs: (ids, c = database, lock = false) => rows(c, `SELECT i.id_insumo,i.id_local,i.id_fornecedor,i.nome,i.status,f.status AS fornecedor_status,u.status AS usuario_status,u.tipo_usuario,fl.status AS vinculo_status FROM insumos i JOIN fornecedores f ON f.id_fornecedor = i.id_fornecedor JOIN usuarios u ON u.id_usuario = f.id_usuario LEFT JOIN fornecedor_locais fl ON fl.id_fornecedor = i.id_fornecedor AND fl.id_local = i.id_local WHERE i.id_insumo IN (${ids.map(() => '?').join(',')}) ORDER BY i.id_insumo${lock ? ' FOR UPDATE' : ''}`, ids),
        items: (id, c = database) => rows(c, 'SELECT ci.id_insumo,ci.quantidade,i.nome FROM combo_itens ci JOIN insumos i ON i.id_insumo = ci.id_insumo WHERE ci.id_combo = ? ORDER BY ci.id_insumo', [id]),
        referenced: async (id, c) => Boolean((await one(c, 'SELECT 1 AS found FROM itens_pedido WHERE id_combo = ? LIMIT 1', [id]))),
        async adminList(c,q) {
            const where=[],args=[];
            if(q.cursor){where.push('c.id_combo<?');args.push(q.cursor);}
            if(q.localId){where.push('c.id_local=?');args.push(q.localId);}
            if(q.active!==undefined){where.push('c.ativo=?');args.push(q.active?1:0);}
            if(q.q){where.push("c.nome LIKE ? ESCAPE '!'");args.push('%'+q.q.replace(/[!%_]/g,v=>'!'+v)+'%');}
            args.push(q.limit+1);
            return rows(c,`SELECT c.id_combo,c.id_local,c.nome,c.descricao,c.preco,c.ativo,c.data_cadastro,
                (SELECT COUNT(*) FROM combo_itens ci WHERE ci.id_combo=c.id_combo) AS item_count
                FROM combos c ${where.length?'WHERE '+where.join(' AND '):''} ORDER BY c.id_combo DESC LIMIT ?`,args);
        },
        async list(q) {
            return rows(database, `SELECT c.id_combo,c.id_local,c.nome,c.descricao,c.preco,c.ativo,c.data_cadastro, (SELECT im.url FROM combos_imagens im WHERE im.id_combo=c.id_combo AND im.tipo='PRINCIPAL' ORDER BY im.ordem,im.id_imagem LIMIT 1) AS imagem FROM combos c JOIN locais l ON l.id_local = c.id_local WHERE c.id_local = ? AND c.id_combo > ? AND c.ativo = 1 AND l.status = 'ATIVO' AND EXISTS (SELECT 1 FROM combo_itens ci WHERE ci.id_combo = c.id_combo) AND NOT EXISTS (SELECT 1 FROM combo_itens ci JOIN insumos i ON i.id_insumo = ci.id_insumo JOIN fornecedores f ON f.id_fornecedor = i.id_fornecedor JOIN usuarios u ON u.id_usuario = f.id_usuario LEFT JOIN fornecedor_locais fl ON fl.id_fornecedor = i.id_fornecedor AND fl.id_local = i.id_local WHERE ci.id_combo = c.id_combo AND (i.id_local <> c.id_local OR i.status <> 'DISPONIVEL' OR f.status <> 'ATIVO' OR u.status <> 'ATIVO' OR u.tipo_usuario <> 'FORNECEDOR' OR fl.status IS NULL OR fl.status <> 'ATIVO')) ORDER BY c.id_combo LIMIT ${q.limit + 1}`, [q.localId, q.cursor ?? '0']);
        },
        async create(c, input) { const [result] = await c.execute('INSERT INTO combos (id_local,nome,descricao,preco,ativo) VALUES (?,?,?,?,1)', [input.localId,input.nome,input.descricao ?? null,input.preco]); return idString(result.insertId); },
        update(c, id, input) { const keys = Object.keys(input); if (!keys.length || keys.some(k => !['nome','descricao','preco','ativo'].includes(k))) throw new TypeError('Campos inválidos'); return c.execute(`UPDATE combos SET ${keys.map(k => `${k} = ?`).join(',')} WHERE id_combo = ?`, [...keys.map(k => input[k]), id]); },
        async replaceItems(c, id, items) { await c.execute('DELETE FROM combo_itens WHERE id_combo = ?', [id]); for (const row of items) await c.execute('INSERT INTO combo_itens (id_combo,id_insumo,quantidade) VALUES (?,?,?)', [id,row.inputId,row.quantidade]); }
    };
}
