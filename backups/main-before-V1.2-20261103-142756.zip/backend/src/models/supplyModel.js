import { idString } from '../utils/dto.js';

export function createSupplyModel(database) {
    const rows = async (c, sql, args = []) => (await c.execute(sql,args))[0];
    const one = async (c, sql, args = []) => (await rows(c,sql,args))[0] ?? null;
    const itemSpec = kind => kind === 'input' ? ['insumos','id_insumo'] : ['equipamentos','id_equipamento'];
    return {
        local: (id,c=database) => one(c,'SELECT id_local,status FROM locais WHERE id_local = ?',[id]),
        supervisorLocation: (userId,c=database) => one(c,'SELECT id_local FROM supervisor_locais WHERE id_supervisor = ?',[userId]),
        availableInputs(localId,q,c=database) {
            if (!Number.isInteger(q.limit) || q.limit < 1 || q.limit > 100) throw new TypeError('Limite inválido');
            return rows(c,`SELECT i.id_insumo,i.nome,i.id_local AS id_local_origem,l.nome AS nome_origem,i.quantidade-i.quantidade_reservada AS disponivel
                FROM insumos i JOIN locais l ON l.id_local=i.id_local JOIN fornecedores f ON f.id_fornecedor=i.id_fornecedor
                JOIN usuarios u ON u.id_usuario=f.id_usuario
                JOIN fornecedor_locais origem ON origem.id_fornecedor=f.id_fornecedor AND origem.id_local=i.id_local
                JOIN fornecedor_locais destino ON destino.id_fornecedor=f.id_fornecedor AND destino.id_local=?
                WHERE i.id_local<>? AND i.id_insumo>? AND i.status='DISPONIVEL' AND i.quantidade-i.quantidade_reservada>0
                AND l.status='ATIVO' AND f.status='ATIVO' AND u.status='ATIVO' AND u.tipo_usuario='FORNECEDOR'
                AND origem.status='ATIVO' AND destino.status='ATIVO'
                ORDER BY i.id_insumo LIMIT ${q.limit+1}`,[localId,localId,q.cursor??'0']);
        },
        stock: async (localId,c=database) => ({
            inputs:await rows(c,"SELECT id_insumo AS id,id_fornecedor,nome,quantidade,quantidade_reservada,status FROM insumos WHERE id_local=? ORDER BY id_insumo",[localId]),
            equipment:await rows(c,"SELECT id_equipamento AS id,id_fornecedor,nome,quantidade,status FROM equipamentos WHERE id_local=? ORDER BY id_equipamento",[localId])
        }),
        incoming: (localId,c=database) => rows(c,"SELECT l.id_logistica,l.id_insumo_origem,l.id_equipamento_origem,l.quantidade,l.status,COALESCE(i.nome,e.nome) AS nome FROM logistica l LEFT JOIN insumos i ON i.id_insumo=l.id_insumo_origem LEFT JOIN equipamentos e ON e.id_equipamento=l.id_equipamento_origem WHERE l.id_local_destino=? AND l.status IN ('ENVIADO','EM_TRANSITO') AND l.id_solicitacao IS NOT NULL ORDER BY l.id_logistica",[localId]),
        session: (id,c=database) => one(c,'SELECT s.id_sessao,s.status,l.id_local,l.status AS local_status FROM sessoes s JOIN salas a ON a.id_sala=s.id_sala JOIN locais l ON l.id_local=a.id_local WHERE s.id_sessao = ?',[id]),
        member: (userId,sessionId,c=database) => one(c,"SELECT e.id_equipe FROM equipes e JOIN equipe_membros m ON m.id_equipe=e.id_equipe AND m.id_usuario=? AND m.status='ATIVO' WHERE e.id_sessao=? AND e.status IN ('ATIVA','FINALIZADA') LIMIT 1",[userId,sessionId]),
        supplierByUser: (id,c=database) => one(c,'SELECT id_fornecedor,status FROM fornecedores WHERE id_usuario = ?',[id]),
        grant: (supplierId,localId,c=database) => one(c,"SELECT f.status AS supplier_status,u.status AS user_status,u.tipo_usuario,fl.status AS grant_status,l.status AS local_status FROM fornecedores f JOIN usuarios u ON u.id_usuario=f.id_usuario JOIN locais l ON l.id_local=? LEFT JOIN fornecedor_locais fl ON fl.id_fornecedor=f.id_fornecedor AND fl.id_local=l.id_local WHERE f.id_fornecedor=?",[localId,supplierId]),
        item(kind,id,c=database,lock=false) { const [table,key]=itemSpec(kind); return one(c,`SELECT ${key},id_fornecedor,id_local,nome,descricao,categoria,quantidade,${kind==='input'?'quantidade_reservada,quantidade_minima,preco,':'numero_patrimonio,'}status FROM ${table} WHERE ${key}=?${lock?' FOR UPDATE':''}`,[id]); },
        request: (id,c=database,lock=false) => one(c,`SELECT id_solicitacao,id_usuario,id_local,id_sessao,id_insumo,id_equipamento,quantidade,status,observacao,data_solicitacao FROM solicitacoes_estoque WHERE id_solicitacao=?${lock?' FOR UPDATE':''}`,[id]),
        listRequests(q,c=database) { const where=['r.id_solicitacao > ?'],args=[q.cursor??'0']; if(q.localId){where.push('r.id_local=?');args.push(q.localId);} if(q.sessionId){where.push('r.id_sessao=?');args.push(q.sessionId);} if(q.userId){where.push('r.id_usuario=?');args.push(q.userId);} if(q.supplierId){where.push('COALESCE(i.id_fornecedor,e.id_fornecedor)=?');args.push(q.supplierId);} return rows(c,`SELECT r.* FROM solicitacoes_estoque r LEFT JOIN insumos i ON i.id_insumo=r.id_insumo LEFT JOIN equipamentos e ON e.id_equipamento=r.id_equipamento WHERE ${where.join(' AND ')} ORDER BY r.id_solicitacao LIMIT ${q.limit+1}`,args); },
        async createRequest(c,d) { const [r]=await c.execute("INSERT INTO solicitacoes_estoque(id_usuario,id_local,id_sessao,id_insumo,id_equipamento,quantidade,status,observacao) VALUES(?,?,?,?,?,?,'PENDENTE',?)",[d.actorId,d.localId,d.sessionId??null,d.inputId??null,d.equipmentId??null,d.quantity,d.note??null]);return idString(r.insertId); },
        setRequest: (c,id,status) => c.execute('UPDATE solicitacoes_estoque SET status=? WHERE id_solicitacao=?',[status,id]),
        shipment: (id,c=database,lock=false) => one(c,`SELECT id_logistica,id_fornecedor,id_local_origem,id_local_destino,id_solicitacao,id_insumo_origem,id_equipamento_origem,id_insumo_destino,quantidade,id_usuario_recebimento,id_usuario_devolucao,data_envio,data_prevista,data_recebimento,data_devolucao,status,observacao FROM logistica WHERE id_logistica=?${lock?' FOR UPDATE':''}`,[id]),
        shipmentByRequest: (id,c=database) => one(c,'SELECT id_logistica,status FROM logistica WHERE id_solicitacao=?',[id]),
        listShipments(q,c=database) { const where=['l.id_logistica > ?'],args=[q.cursor??'0'];if(q.supplierId){where.push('l.id_fornecedor=?');args.push(q.supplierId);}if(q.localId){where.push('l.id_local_destino=?');args.push(q.localId);}if(q.sessionId){where.push('r.id_sessao=?');args.push(q.sessionId);}return rows(c,`SELECT l.id_logistica,l.id_fornecedor,l.id_local_origem,l.id_local_destino,l.id_solicitacao,l.id_insumo_origem,l.id_equipamento_origem,l.id_insumo_destino,l.quantidade,l.id_usuario_recebimento,l.id_usuario_devolucao,l.data_envio,l.data_prevista,l.data_recebimento,l.data_devolucao,l.status,l.observacao FROM logistica l LEFT JOIN solicitacoes_estoque r ON r.id_solicitacao=l.id_solicitacao WHERE ${where.join(' AND ')} ORDER BY l.id_logistica LIMIT ${q.limit+1}`,args);},
        async createShipment(c,d) { const [r]=await c.execute("INSERT INTO logistica(id_fornecedor,id_local_origem,id_local_destino,id_solicitacao,id_insumo_origem,id_equipamento_origem,quantidade,status,observacao) VALUES(?,?,?,?,?,?,?,'PENDENTE',?)",[d.supplierId,d.originId,d.destinationId,d.requestId,d.inputId??null,d.equipmentId??null,d.quantity,d.note??null]);return idString(r.insertId);},
        setShipment: (c,id,status,receiver=null) => c.execute(`UPDATE logistica SET status=?,${status==='ENVIADO'?'data_envio=NOW()':status==='RECEBIDO'?'data_recebimento=NOW(),id_usuario_recebimento=?':'observacao=observacao'} WHERE id_logistica=?`,status==='RECEBIDO'?[status,receiver,id]:[status,id]),
        setDestinationItem: (c,id,itemId) => c.execute('UPDATE logistica SET id_insumo_destino=? WHERE id_logistica=?',[itemId,id]),
        setReturned: (c,id,actorId) => c.execute("UPDATE logistica SET status='DEVOLVIDO',data_devolucao=NOW(),id_usuario_devolucao=? WHERE id_logistica=? AND status='RECEBIDO'",[actorId,id]),
        async cloneInput(c,source,destinationId) { const [r]=await c.execute("INSERT INTO insumos(id_fornecedor,id_local,nome,descricao,categoria,quantidade,quantidade_reservada,quantidade_minima,preco,status) VALUES(?,?,?,?,?,0,0,?,?, 'DISPONIVEL')",[source.id_fornecedor,destinationId,source.nome,source.descricao,source.categoria,source.quantidade_minima,source.preco]);return idString(r.insertId);},
        changeInput: (c,id,delta) => c.execute('UPDATE insumos SET quantidade=quantidade+? WHERE id_insumo=? AND quantidade+? BETWEEN quantidade_reservada AND 2147483647',[delta,id,delta]),
        changeEquipment: (c,id,destinationId) => c.execute('UPDATE equipamentos SET id_local=? WHERE id_equipamento=?',[destinationId,id]),
        async movement(c,d) { const [r]=await c.execute('INSERT INTO movimentacoes_estoque(id_insumo,id_equipamento,id_reserva,id_logistica,id_usuario,tipo,quantidade,motivo) VALUES(?,?,NULL,?,?,?,?,?)',[d.inputId??null,d.equipmentId??null,d.shipmentId,d.actorId,d.type,d.quantity,d.reason]);return idString(r.insertId); },
        equipmentInTransit: (id,c) => one(c,"SELECT id_logistica FROM logistica WHERE id_equipamento_origem=? AND status IN ('PENDENTE','ENVIADO','EM_TRANSITO') LIMIT 1",[id])
    };
}
