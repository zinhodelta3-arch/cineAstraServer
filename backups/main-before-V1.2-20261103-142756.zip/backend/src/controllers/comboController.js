import { success } from '../utils/dto.js';
const context = req => ({ actor: req.usuario, signal: req.signal, requestId: req.res.locals.requestId });
export function createComboController(service) {
    return {
        list: async (req, res) => success(res, await service.list(req.comboQuery)),
        get: async (req, res) => success(res, await service.get(req.params.id)),
        adminList: async (req,res) => success(res,await service.adminList(req.comboQuery,context(req))),
        adminGet: async (req, res) => success(res, await service.adminGet(req.params.id, context(req))),
        unitList: async (req, res) => success(res, await service.unitList(req.comboQuery, context(req))),
        unitGet: async (req, res) => success(res, await service.unitGet(req.params.id, context(req))),
        unitCreate: async (req, res) => success(res, await service.create(req.input, context(req), true), 201),
        unitPatch: async (req, res) => success(res, await service.patch(req.params.id, req.input, context(req), true)),
        unitReplace: async (req, res) => success(res, await service.replace(req.params.id, req.input, context(req), true)),
        unitArchive: async (req, res) => { await service.archive(req.params.id, context(req), true); res.sendStatus(204); },
        create: async (req, res) => { const data = await service.create(req.input, context(req)); res.location(`/api/admin/combos/${data.id_combo}`); success(res, data, 201); },
        patch: async (req, res) => success(res, await service.patch(req.params.id, req.input, context(req))),
        replace: async (req, res) => success(res, await service.replace(req.params.id, req.input, context(req))),
        archive: async (req, res) => { await service.archive(req.params.id, context(req)); res.sendStatus(204); }
    };
}
