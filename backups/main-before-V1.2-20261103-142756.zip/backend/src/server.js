import { createServer } from 'node:http';
import { pathToFileURL } from 'node:url';
import { EnvironmentValidationError, loadEnvironment } from './config/env.js';
import { runtimeConfig } from './config/runtime.js';
import { createDatabase } from './config/database.js';
import { createApp } from './app.js';
import { simulatedPaymentProvider } from './providers/paymentProvider.js';
import { createLogModel } from './models/logModel.js';
import { createLogQueue } from './services/logService.js';
import { createLogRetention } from './jobs/logRetention.js';
import { createCheckoutExpiry } from './jobs/checkoutExpiry.js';
import {createSubscriptionBillingJob} from './jobs/subscriptionBilling.js';
import {createNewsletterDeliveryJob} from './jobs/newsletterDelivery.js';
import {createSupportLiveExpiry} from './jobs/supportLiveExpiry.js';
import { report } from './utils/telemetry.js';

export async function startServer(config, overrides = {}) {
    const database = overrides.database ?? createDatabase(config.db);
    const model = createLogModel(database);
    const queue = overrides.logQueue ?? createLogQueue(log => model.insert(log), { limit: config.logging.queueLimit });
    const retention = overrides.retention ?? createLogRetention(model, config.logging);
    const lifecycle = { stopping: false };
    let app;
    try { app = createApp({ config, database, logQueue: queue, retention, lifecycle, identityProviders: overrides.identityProviders, captchaProvider: overrides.captchaProvider, paymentProvider: overrides.paymentProvider ?? (config.paymentMode === 'SIMULATED' ? simulatedPaymentProvider() : undefined), streamingProvider: overrides.streamingProvider, newsletterEmailProvider: overrides.newsletterEmailProvider, assistantProvider: overrides.assistantProvider, ipcaProvider: overrides.ipcaProvider, storeFactory: overrides.storeFactory }); }
    catch (error) { await queue.close(); await database.close(); throw error; }
    const server = createServer(app);
    server.requestTimeout = config.httpTimeout;
    server.headersTimeout = Math.min(config.httpTimeout, 5000);
    server.keepAliveTimeout = 5000;
    server.setTimeout(config.httpTimeout, socket => socket.destroy());
    try {
        await new Promise((resolve, reject) => { server.once('error', reject); server.listen(config.port, config.host, () => { server.removeListener('error', reject); resolve(); }); });
    } catch (error) { await app.locals.close(); await queue.close(); await database.close(); throw error; }
    retention.start();
    const checkoutExpiry=createCheckoutExpiry(app.locals.checkout);
    checkoutExpiry.start();
    const subscriptionBilling=createSubscriptionBillingJob(app.locals.billing);
    subscriptionBilling.start();
    const newsletterDelivery=createNewsletterDeliveryJob(app.locals.newsletterDelivery);
    if(app.locals.newsletterDeliveryEnabled)newsletterDelivery.start();
    const supportLiveExpiry=createSupportLiveExpiry(app.locals.support);
    supportLiveExpiry.start();
    let shutdown;
    return { server, app, lifecycle, close() {
        shutdown ??= (async () => {
            lifecycle.stopping = true;
            const force = setTimeout(() => server.closeAllConnections(), config.shutdownTimeout);
            try {
                await new Promise(resolve => { server.close(resolve); server.closeIdleConnections(); });
                let failed = false;
                for (const close of [() => supportLiveExpiry.close(), () => newsletterDelivery.close(), () => subscriptionBilling.close(), () => checkoutExpiry.close(), () => retention.close(), () => queue.close(), () => app.locals.close(), () => database.close()]) {
                    try { await close(); }
                    catch { failed = true; report('shutdown_resource_failed'); }
                }
                if (failed) throw new Error('Encerramento incompleto');
            } finally { clearTimeout(force); }
        })();
        return shutdown;
    } };
}

async function main() {
    let runtime;
    try {
        loadEnvironment();
        const config = runtimeConfig();
        runtime = await startServer(config);
        console.info('CineAstra API iniciada; consulte /ready para prontidão.');
        const stop = () => {
            const force = setTimeout(() => { report('shutdown_timeout'); process.exit(1); }, config.shutdownTimeout);
            runtime.close().then(() => { clearTimeout(force); process.exitCode = 0; }, () => { report('shutdown_failed'); process.exit(1); });
        };
        process.once('SIGINT', stop);
        process.once('SIGTERM', stop);
    } catch (error) {
        if (error instanceof EnvironmentValidationError) {
            console.error(JSON.stringify({ event: 'startup_failed_check_environment', fields: error.fields }));
        } else {
            report('startup_failed_check_environment');
        }
        process.exitCode = 1;
    }
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) await main();
