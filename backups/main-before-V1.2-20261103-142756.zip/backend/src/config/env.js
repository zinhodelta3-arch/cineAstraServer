import dotenv from 'dotenv';
import { fileURLToPath } from 'node:url';
import { isIP } from 'node:net';
import { isAbsolute } from 'node:path';

export function loadEnvironment() {
    dotenv.config({ path: fileURLToPath(new URL('../../.env', import.meta.url)), quiet: true });
}

export class EnvironmentValidationError extends Error {
    constructor(fields) {
        const names = [...fields].sort();
        super(`Configuração inválida: ${names.join(', ')}`);
        this.fields = names;
    }
}

export function validateEnv(env = process.env) {
    const errors = new Set();
    const required = (key) => {
        const value = env[key];
        if (typeof value !== 'string' || !value.trim()) errors.add(key);
        return value;
    };
    const integer = (key, fallback, min, max) => {
        const text = env[key] ?? String(fallback);
        const value = Number(text);
        if (!/^\d+$/.test(String(text)) || !Number.isSafeInteger(value) || value < min || value > max) errors.add(key);
        return value;
    };
    const boolean = (key, fallback) => {
        const text = env[key] ?? String(fallback);
        if (!['true', 'false'].includes(text)) errors.add(key);
        return text === 'true';
    };
    const mode = env.NODE_ENV ?? 'development';
    if (!['development', 'test', 'staging', 'production'].includes(mode)) errors.add('NODE_ENV');
    const production = mode === 'production';
    const origins = (env.CORS_ORIGINS ?? env.FRONTEND_URL ?? (production ? '' : 'http://localhost:3000')).split(',').map(s => s.trim()).filter(Boolean);
    const validOrigin = value => {
        try { const u = new URL(value); return ['http:', 'https:'].includes(u.protocol) && !u.username && !u.password && u.origin === value; }
        catch { return false; }
    };
    if (!origins.length || origins.some(o => !validOrigin(o))) errors.add('CORS_ORIGINS');
    const secret = required('JWT_SECRET');
    if (secret && (Buffer.byteLength(secret) < 32 || /^(change|example|secret|senha|replace)/i.test(secret))) errors.add('JWT_SECRET');
    const docsEnabled = boolean('DOCS_ENABLED', !production);
    if (production && docsEnabled) errors.add('DOCS_ENABLED');
    const trustProxy = (env.TRUST_PROXY ?? '').split(',').map(s => s.trim()).filter(Boolean);
    // Endereços/subnets de proxies reais; nunca "true", contagem de hops ou redes globais.
    if (trustProxy.some(v => {
        const [address, prefix, extra] = v.split('/');
        const family = isIP(address);
        return !family || extra !== undefined || (prefix !== undefined && (!/^\d{1,3}$/.test(prefix) || Number(prefix) < 1 || Number(prefix) > (family === 4 ? 32 : 128)));
    })) errors.add('TRUST_PROXY');
    const instances = integer('INSTANCE_COUNT', 1, 1, 1000);
    const rateLimitStore = env.RATE_LIMIT_STORE ?? 'memory';
    if (!['memory', 'external'].includes(rateLimitStore) || (instances > 1 && rateLimitStore === 'memory')) errors.add('RATE_LIMIT_STORE');
    const retentionMode = env.LOG_RETENTION_MODE ?? 'worker';
    if (!['event', 'worker'].includes(retentionMode)) errors.add('LOG_RETENTION_MODE');
    const publicOrigin = env.PUBLIC_ORIGIN ?? `http://localhost:${env.PORT ?? 8080}`;
    if (!validOrigin(publicOrigin)) errors.add('PUBLIC_ORIGIN');
    const sampleRate = Number(env.LOG_SUCCESS_SAMPLE_RATE ?? 0.05);
    if (!Number.isFinite(sampleRate) || sampleRate < 0 || sampleRate > 1) errors.add('LOG_SUCCESS_SAMPLE_RATE');
    if ((env.CAPTCHA_PROVIDER ?? 'unavailable') !== 'unavailable') errors.add('CAPTCHA_PROVIDER');
    const encryptionKey = env.TWO_FACTOR_ENCRYPTION_KEY || null;
    if (encryptionKey && (!/^[A-Za-z0-9+/]{43}=$/.test(encryptionKey) || Buffer.from(encryptionKey, 'base64').length !== 32)) errors.add('TWO_FACTOR_ENCRYPTION_KEY');
    const mediaHosts = (env.CATALOG_MEDIA_HOSTS ?? '').split(',').map(v => v.trim().toLowerCase()).filter(Boolean);
    if (mediaHosts.some(v => !/^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(v))) errors.add('CATALOG_MEDIA_HOSTS');
    const config = {
        imageUpload: { directory: env.IMAGE_STAGING_DIR || (!production ? fileURLToPath(new URL('../../.storage/images', import.meta.url)) : null) },
        gallery: { directory: env.IMAGE_GALLERY_DIR || (!production ? fileURLToPath(new URL('../../.storage/gallery', import.meta.url)) : null) },
        catalog: { mediaHosts },
        security: { captchaEnabled: boolean('CAPTCHA_ENABLED', false), twoFactorEnabled: boolean('TWO_FACTOR_ENABLED', false) },
        mode, production, docsEnabled, origins, trustProxy, publicOrigin, instances, rateLimitStore,
        host: env.HOST ?? '0.0.0.0', port: integer('PORT', 8080, 1, 65535),
        bodyLimit: integer('BODY_LIMIT_BYTES', 65536, 1024, 1048576),
        httpTimeout: integer('HTTP_TIMEOUT_MS', 10000, 100, 10000),
        shutdownTimeout: integer('SHUTDOWN_TIMEOUT_MS', 10000, 100, 30000),
        jwt: { secret, issuer: env.JWT_ISSUER ?? 'cineastra', audience: env.JWT_AUDIENCE ?? 'cineastra-web', ttl: integer('JWT_TTL_SECONDS', 86400, 60, 86400) },
        identity: { allowLocalRegistrationDocuments: boolean('ALLOW_LOCAL_REGISTRATION_DOCUMENTS', true), allowSelfDeclaredAge: boolean('ALLOW_SELF_DECLARED_AGE', true), encryptionKey, bcryptCost: integer('BCRYPT_COST', 12, 10, 14), termsVersion: env.TERMS_VERSION || null, privacyVersion: env.PRIVACY_VERSION || null, legalBasis: env.IDENTITY_LEGAL_BASIS || null },
        paymentMode: env.PAYMENT_MODE || (production ? 'UNAVAILABLE' : 'SIMULATED'),
        db: { host: required('DB_HOST'), port: integer('DB_PORT', 3306, 1, 65535), user: required('DB_USER'), password: required('DB_PASSWORD'), database: required('DB_NAME'),
            connectionLimit: integer('DB_CONNECTION_LIMIT', 10, 1, 100), queueLimit: integer('DB_QUEUE_LIMIT', 100, 1, 1000), timeout: integer('DB_TIMEOUT_MS', 3000, 100, 5000) },
        rate: { max: integer('RATE_LIMIT_MAX', 120, 1, 10000), windowMs: integer('RATE_LIMIT_WINDOW_MS', 60000, 100, 3600000) },
        logging: { queueLimit: integer('LOG_QUEUE_LIMIT', 200, 1, 10000), sampleRate, retentionMode, purgeInterval: integer('LOG_PURGE_INTERVAL_MS', 900000, 60000, 3600000) }
    };
    if (!['SIMULATED', 'UNAVAILABLE'].includes(config.paymentMode)) errors.add('PAYMENT_MODE');
    if (config.db.database && !/^[a-zA-Z0-9_]+$/.test(config.db.database)) errors.add('DB_NAME');
    if (typeof config.jwt.issuer !== 'string' || !config.jwt.issuer.trim()) errors.add('JWT_ISSUER');
    if (typeof config.jwt.audience !== 'string' || !config.jwt.audience.trim()) errors.add('JWT_AUDIENCE');
    if (config.imageUpload.directory && !isAbsolute(config.imageUpload.directory)) errors.add('IMAGE_STAGING_DIR');
    if (config.gallery.directory && !isAbsolute(config.gallery.directory)) errors.add('IMAGE_GALLERY_DIR');
    if (config.gallery.directory && config.imageUpload.directory && config.gallery.directory === config.imageUpload.directory) errors.add('IMAGE_GALLERY_DIR');
    if (instances > 1) config.imageUpload.directory = null; // Staging local exige instância única.
    if (instances > 1) config.gallery.directory = null;
    if (config.db.timeout >= config.httpTimeout) errors.add('DB_TIMEOUT_MS');
    for (const [key, value, max] of [['TERMS_VERSION', config.identity.termsVersion, 50], ['PRIVACY_VERSION', config.identity.privacyVersion, 50], ['IDENTITY_LEGAL_BASIS', config.identity.legalBasis, 100]]) {
        if (value && (!value.trim() || value.length > max)) errors.add(key);
    }
    if (errors.size) throw new EnvironmentValidationError(errors);
    return Object.freeze(config);
}
